<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBooksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    
    //upメソッド
    //新しいテーブル、カラム、インデックスをデータベース追加するために使用
    public function up()
    {
        Schema::create('books', function (Blueprint $table) {
            $table->increments('id'); //カラム定義
            $table->string('item_name');
            $table->integer('item_number');
            $table->integer('item_amount');
            $table->datetime('published');
            $table->timestamps();     //カラム定義
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
     
     //downメソッド
     //upメソッドで作成したテーブルを削除します。
    public function down()
    {
        Schema::dropIfExists('books');
    }
}
